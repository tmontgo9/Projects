#!/bin/bash




mpiexec  ./hello
